
# Add AI/LLM advanced automation scenarios
automation_scenarios["AI 및 LLM 응용 (고급)"] = [
    {
        "시나리오": "AI 기반 이메일 자동 분류 및 요약",
        "난이도": "고급",
        "Python_라이브러리": "openai, transformers, pandas",
        "주요_단계": "이메일 수신 → LLM 분석 → 카테고리 분류 → 요약 생성 → 라우팅",
        "n8n_노드": "Gmail Trigger → OpenAI → Switch → Set → Multiple actions",
        "적용_부서": "고객지원, 영업팀",
        "도입_효과": "이메일 분류 정확도 95%, 1차 응답 시간 85% 단축",
        "확장_아이디어": "감정 분석 기반 우선순위 자동 조정"
    },
    {
        "시나리오": "문서 자동 번역 및 다국어 처리",
        "난이도": "고급",
        "Python_라이브러리": "openai, googletrans, docx",
        "주요_단계": "문서 업로드 → 텍스트 추출 → AI 번역 → 포맷 유지 → 저장",
        "n8n_노드": "Webhook → Extract Text → OpenAI (translation) → Generate Doc → Save",
        "적용_부서": "글로벌 운영팀, 마케팅",
        "도입_효과": "번역 비용 80% 절감, 처리 시간 90% 단축",
        "확장_아이디어": "맥락 기반 전문 용어 자동 처리"
    },
    {
        "시나리오": "AI 챗봇 기반 FAQ 자동 응답",
        "난이도": "고급",
        "Python_라이브러리": "openai, langchain, chromadb",
        "주요_단계": "질문 수신 → 벡터 검색 → LLM 답변 생성 → 응답 발송",
        "n8n_노드": "Slack Trigger → Pinecone → OpenAI → Slack Reply",
        "적용_부서": "IT지원, 고객서비스",
        "도입_효과": "문의 응답률 95%, 상담사 업무량 60% 감소",
        "확장_아이디어": "대화 이력 학습으로 정확도 지속 향상"
    },
    {
        "시나리오": "회의록 자동 생성 및 액션 아이템 추출",
        "난이도": "고급",
        "Python_라이브러리": "openai-whisper, openai, python-docx",
        "주요_단계": "음성 녹음 → STT 변환 → LLM 요약 → 액션 아이템 추출 → 분배",
        "n8n_노드": "Webhook → Whisper API → OpenAI → Parse → Multiple assignments",
        "적용_부서": "전 부서",
        "도입_효과": "회의록 작성 시간 100% 절약, 액션 아이템 추적율 향상",
        "확장_아이디어": "자동 팔로업 알림 및 진행 상황 추적"
    },
    {
        "시나리오": "고객 피드백 감정 분석 및 인사이트",
        "난이도": "고급",
        "Python_라이브러리": "openai, pandas, matplotlib",
        "주요_단계": "피드백 수집 → 감정 분석 → 주제 추출 → 트렌드 분석 → 리포트",
        "n8n_노드": "Schedule → Database → OpenAI (sentiment) → Aggregate → Dashboard",
        "적용_부서": "고객경험팀, 제품팀",
        "도입_효과": "고객 불만 조기 발견, 제품 개선 인사이트 도출",
        "확장_아이디어": "실시간 고객 감정 대시보드 및 알림"
    },
    {
        "시나리오": "AI 기반 콘텐츠 자동 생성",
        "난이도": "고급",
        "Python_라이브러리": "openai, jinja2, requests",
        "주요_단계": "데이터 입력 → 프롬프트 생성 → AI 콘텐츠 작성 → 검토 → 발행",
        "n8n_노드": "Schedule → Database → OpenAI → Human Review → CMS Publish",
        "적용_부서": "마케팅, 콘텐츠팀",
        "도입_효과": "콘텐츠 제작 시간 70% 단축, 일관성 향상",
        "확장_아이디어": "A/B 테스트 자동화 및 성과 분석"
    },
    {
        "시나리오": "계약서 자동 검토 및 리스크 분석",
        "난이도": "AI응용",
        "Python_라이브러리": "openai, PyPDF2, pandas",
        "주요_단계": "계약서 업로드 → 텍스트 추출 → AI 분석 → 리스크 플래그 → 알림",
        "n8n_노드": "Webhook → Extract Text → OpenAI → IF → Legal Team Notification",
        "적용_부서": "법무팀, 구매팀",
        "도입_효과": "검토 시간 80% 단축, 리스크 식별율 향상",
        "확장_아이디어": "과거 계약 학습으로 표준 조항 자동 제안"
    },
    {
        "시나리오": "지능형 데이터 품질 검증",
        "난이도": "AI응용",
        "Python_라이브러리": "openai, pandas, great_expectations",
        "주요_단계": "데이터 로드 → AI 이상 탐지 → 패턴 분석 → 자동 수정 제안",
        "n8n_노드": "Schedule → Database → OpenAI → IF → Data Quality Report",
        "적용_부서": "데이터팀, BI팀",
        "도입_효과": "데이터 품질 향상, 수동 검증 시간 90% 절감",
        "확장_아이디어": "예측 기반 데이터 오류 방지"
    }
]

# Create comprehensive DataFrame with all scenarios
all_scenarios = []
scenario_id = 1

for category, scenarios in automation_scenarios.items():
    for scenario in scenarios:
        scenario_data = {
            "ID": f"시나리오_{scenario_id:02d}",
            "카테고리": category,
            "시나리오명": scenario["시나리오"],
            "난이도": scenario["난이도"],
            "Python/JS_라이브러리": scenario["Python_라이브러리"],
            "주요_처리_단계": scenario["주요_단계"],
            "n8n_노드_구성": scenario["n8n_노드"],
            "적용_부서": scenario["적용_부서"],
            "도입_효과": scenario["도입_효과"],
            "확장_아이디어": scenario["확장_아이디어"]
        }
        all_scenarios.append(scenario_data)
        scenario_id += 1

df = pd.DataFrame(all_scenarios)

# Save to CSV
df.to_csv('automation_scenarios_comprehensive.csv', index=False, encoding='utf-8-sig')

print(f"총 {len(all_scenarios)}개 시나리오 생성 완료")
print(f"\n난이도별 분포:")
print(df['난이도'].value_counts().sort_index())
print(f"\n카테고리별 분포:")
print(df['카테고리'].value_counts())
print("\nCSV 파일 저장 완료: automation_scenarios_comprehensive.csv")

# Show first few examples
print("\n=== 샘플 시나리오 (처음 3개) ===")
print(df[['ID', '카테고리', '시나리오명', '난이도']].head(3).to_string(index=False))
