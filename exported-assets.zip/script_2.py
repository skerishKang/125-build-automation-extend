
# Create detailed comparison tables for representative scenarios
comparison_examples = [
    {
        "시나리오": "메일 첨부파일 자동 다운로드 및 분류",
        "비교표": {
            "항목": ["트리거", "조건 필터링", "파일 저장", "로그 기록", "장점", "단점"],
            "Python 구현": [
                "imaplib.IMAP4_SSL() 폴링",
                "if 'invoice' in subject",
                "os.rename(), shutil.move()",
                "logging.info() / CSV",
                "세밀한 커스텀, 복잡한 로직 가능",
                "코드 작성 필요, 유지보수 부담"
            ],
            "n8n 구성": [
                "Gmail Trigger (자동)",
                "IF Node (시각적 조건)",
                "Move File Node",
                "Google Sheets Append",
                "시각적 편집, 빠른 구축",
                "복잡한 로직은 Function 노드 필요"
            ]
        },
        "구현_복잡도": "Python 3/5, n8n 1/5",
        "유지보수성": "Python 2/5, n8n 5/5",
        "확장성": "Python 5/5, n8n 4/5"
    },
    {
        "시나리오": "청구서 OCR 자동 처리",
        "비교표": {
            "항목": ["데이터 입력", "OCR 처리", "데이터 추출", "검증", "DB 저장", "장점", "단점"],
            "Python 구현": [
                "email.message 파싱",
                "pytesseract.image_to_string()",
                "정규식 + 패턴 매칭",
                "pandas validation rules",
                "sqlalchemy ORM",
                "고급 전처리 가능, ML 통합",
                "OCR 라이브러리 설정 복잡"
            ],
            "n8n 구성": [
                "Email Trigger / Webhook",
                "HTTP Request (OCR.space API)",
                "Function Node (JSON 파싱)",
                "IF Node + Switch",
                "MySQL / PostgreSQL Node",
                "API 통합 간편, 빠른 프로토타입",
                "OCR API 비용, 정확도 API 의존"
            ]
        },
        "구현_복잡도": "Python 4/5, n8n 2/5",
        "유지보수성": "Python 3/5, n8n 4/5",
        "확장성": "Python 5/5, n8n 4/5"
    },
    {
        "시나리오": "AI 기반 고객 문의 자동 분류",
        "비교표": {
            "항목": ["입력", "전처리", "AI 분석", "분류", "라우팅", "장점", "단점"],
            "Python 구현": [
                "IMAP / API 호출",
                "텍스트 정제 (re, nltk)",
                "openai.ChatCompletion.create()",
                "response parsing + logic",
                "API call to CRM/Ticket system",
                "커스텀 모델 fine-tuning 가능",
                "프롬프트 엔지니어링 코드 관리 필요"
            ],
            "n8n 구성": [
                "Email Trigger / Webhook",
                "Function Node (optional)",
                "OpenAI Node (GPT-4)",
                "Switch Node (category)",
                "Zendesk / Slack / Email nodes",
                "프롬프트 UI에서 수정 용이",
                "복잡한 프롬프트 체인은 여러 노드 필요"
            ]
        },
        "구현_복잡도": "Python 4/5, n8n 2/5",
        "유지보수성": "Python 2/5, n8n 5/5",
        "확장성": "Python 5/5, n8n 4/5"
    },
    {
        "시나리오": "ETL 파이프라인 (다중 소스)",
        "비교표": {
            "항목": ["데이터 추출", "변환", "집계", "적재", "스케줄링", "장점", "단점"],
            "Python 구현": [
                "pandas.read_sql() / API",
                "df.apply(), merge(), transform()",
                "groupby(), agg(), pivot()",
                "to_sql() / sqlalchemy",
                "APScheduler / Airflow",
                "대용량 처리 최적화, Dask 확장",
                "인프라 구축 필요, 모니터링 별도"
            ],
            "n8n 구성": [
                "Multiple DB Query Nodes",
                "Function Node / Code Node",
                "Aggregate Node",
                "PostgreSQL / MySQL Node",
                "Schedule Trigger (cron)",
                "시각적 데이터 플로우, 에러 핸들링 UI",
                "대용량 데이터는 성능 제약"
            ]
        },
        "구현_복잡도": "Python 4/5, n8n 3/5",
        "유지보수성": "Python 3/5, n8n 4/5",
        "확장성": "Python 5/5, n8n 3/5"
    }
]

# Save detailed comparison tables
comparison_df_list = []

for idx, example in enumerate(comparison_examples, 1):
    comp_data = example["비교표"]
    df_comp = pd.DataFrame(comp_data)
    
    print(f"\n{'='*80}")
    print(f"상세 비교표 {idx}: {example['시나리오']}")
    print('='*80)
    print(df_comp.to_string(index=False))
    print(f"\n평가:")
    print(f"  - 구현 복잡도: {example['구현_복잡도']}")
    print(f"  - 유지보수성: {example['유지보수성']}")
    print(f"  - 확장성: {example['확장성']}")
    
    # Add scenario name to dataframe
    df_comp.insert(0, '시나리오', example['시나리오'])
    comparison_df_list.append(df_comp)

# Combine all comparison tables
all_comparisons = pd.concat(comparison_df_list, ignore_index=True)
all_comparisons.to_csv('automation_comparison_tables.csv', index=False, encoding='utf-8-sig')

print(f"\n\n상세 비교표 CSV 저장 완료: automation_comparison_tables.csv")
