
import pandas as pd
import json

# Create a comprehensive list of automation scenarios organized by category and difficulty
automation_scenarios = {
    "메일 자동화": [
        {
            "시나리오": "메일 첨부파일 자동 다운로드 및 분류",
            "난이도": "입문",
            "Python_라이브러리": "imaplib, os, datetime",
            "주요_단계": "이메일 수신 → 첨부파일 추출 → 폴더별 저장 → 로그 작성",
            "n8n_노드": "Gmail Trigger → IF Node → Move File → Google Sheets",
            "적용_부서": "회계팀, 고객지원팀",
            "도입_효과": "월말 보고서 자동 분류, 고객 문의 첨부파일 정리 시간 70% 단축",
            "확장_아이디어": "OCR로 청구서 데이터 자동 추출 및 ERP 연동"
        },
        {
            "시나리오": "이메일 자동 응답 및 분류",
            "난이도": "기초",
            "Python_라이브러리": "smtplib, email, re",
            "주요_단계": "메일 읽기 → 키워드 분석 → 자동 응답 생성 → 분류 라벨 부착",
            "n8n_노드": "Gmail Trigger → Switch Node → Gmail Send → Set Labels",
            "적용_부서": "고객서비스, 영업팀",
            "도입_효과": "고객 문의 응답 시간 80% 단축, 1차 응답 자동화",
            "확장_아이디어": "감정 분석으로 긴급도 자동 판별 및 에스컬레이션"
        },
        {
            "시나리오": "대량 메일 발송 및 추적",
            "난이도": "중급",
            "Python_라이브러리": "pandas, jinja2, smtplib",
            "주요_단계": "수신자 목록 로드 → 템플릿 렌더링 → 개인화 발송 → 오픈율 추적",
            "n8n_노드": "Google Sheets → Loop → Email Send → HTTP Request (tracking)",
            "적용_부서": "마케팅, HR",
            "도입_효과": "뉴스레터 발송 자동화, 개인화율 향상으로 오픈율 35% 증가",
            "확장_아이디어": "A/B 테스트 자동화 및 최적 발송 시간 학습"
        }
    ],
    
    "파일 및 문서 처리": [
        {
            "시나리오": "파일명 일괄 변경 및 정리",
            "난이도": "입문",
            "Python_라이브러리": "os, shutil, datetime",
            "주요_단계": "폴더 스캔 → 규칙 적용 → 파일명 변경 → 백업",
            "n8n_노드": "Schedule Trigger → Read Files → Set → Move/Rename File",
            "적용_부서": "전 부서",
            "도입_효과": "파일 검색 시간 60% 단축, 명명 규칙 표준화",
            "확장_아이디어": "파일 내용 분석으로 자동 태깅 및 분류"
        },
        {
            "시나리오": "PDF 자동 생성 및 배포",
            "난이도": "기초",
            "Python_라이브러리": "reportlab, PyPDF2, pandas",
            "주요_단계": "데이터 조회 → PDF 템플릿 적용 → 생성 → 이메일 발송",
            "n8n_노드": "Schedule → Database Query → HTTP (PDF API) → Email",
            "적용_부서": "재무팀, 영업팀",
            "도입_효과": "주간 보고서 생성 시간 90% 단축 (8시간→45분)",
            "확장_아이디어": "인터랙티브 대시보드 포함 PDF 자동 생성"
        },
        {
            "시나리오": "엑셀 데이터 통합 및 리포트 자동화",
            "난이도": "기초",
            "Python_라이브러리": "pandas, openpyxl, xlsxwriter",
            "주요_단계": "다중 파일 로드 → 데이터 병합 → 집계 계산 → 리포트 생성",
            "n8n_노드": "Schedule → Read Binary Files → Function → Spreadsheet File",
            "적용_부서": "재무, 운영팀",
            "도입_효과": "월간 보고서 작성 시간 70% 단축, 오류율 95% 감소",
            "확장_아이디어": "실시간 대시보드 연동 및 이상치 자동 알림"
        },
        {
            "시나리오": "문서 승인 워크플로우 자동화",
            "난이도": "중급",
            "Python_라이브러리": "docx-python, flask, sqlalchemy",
            "주요_단계": "문서 업로드 → 승인자 라우팅 → 알림 발송 → 상태 추적",
            "n8n_노드": "Webhook → IF (조건) → Multiple Email → Update Database",
            "적용_부서": "전 부서",
            "도입_효과": "승인 소요 시간 75% 단축 (7일→1.75일), 병목 가시화",
            "확장_아이디어": "AI로 승인 필요 항목 자동 하이라이트"
        },
        {
            "시나리오": "OCR 기반 청구서 데이터 추출",
            "난이도": "중급",
            "Python_라이브러리": "pytesseract, opencv, pandas",
            "주요_단계": "이미지/PDF 로드 → OCR 처리 → 데이터 추출 → DB 저장",
            "n8n_노드": "Email Trigger → HTTP (OCR API) → Set → MySQL",
            "적용_부서": "회계팀, 구매팀",
            "도입_효과": "청구서 처리 시간 85% 단축, 연간 비용 30% 절감",
            "확장_아이디어": "3-way 매칭 자동화 (PO-영수증-청구서)"
        }
    ],
    
    "데이터 처리 및 ETL": [
        {
            "시나리오": "CSV 파일 변환 및 정제",
            "난이도": "입문",
            "Python_라이브러리": "pandas, numpy",
            "주요_단계": "파일 읽기 → 결측치 처리 → 포맷 변환 → 저장",
            "n8n_노드": "Schedule → Read File → Function (transform) → Write File",
            "적용_부서": "데이터팀, 분석팀",
            "도입_효과": "데이터 정제 시간 80% 단축, 일관성 보장",
            "확장_아이디어": "데이터 품질 자동 검증 및 알림"
        },
        {
            "시나리오": "데이터베이스 백업 자동화",
            "난이도": "기초",
            "Python_라이브러리": "subprocess, zipfile, boto3",
            "주요_단계": "DB 덤프 → 압축 → 클라우드 업로드 → 알림",
            "n8n_노드": "Schedule → Execute Command → AWS S3 → Slack",
            "적용_부서": "IT팀, 개발팀",
            "도입_효과": "백업 누락 제로화, 복구 시간 90% 단축",
            "확장_아이디어": "자동 복구 테스트 및 무결성 검증"
        },
        {
            "시나리오": "ETL 파이프라인 구축",
            "난이도": "중급",
            "Python_라이브러리": "pandas, sqlalchemy, apache-airflow",
            "주요_단계": "다중 소스 추출 → 변환/집계 → 데이터 웨어하우스 적재",
            "n8n_노드": "Schedule → Multiple DB Queries → Merge → PostgreSQL",
            "적용_부서": "데이터팀, BI팀",
            "도입_효과": "데이터 파이프라인 구축 시간 60% 단축, 신뢰성 향상",
            "확장_아이디어": "실시간 스트리밍 데이터 처리 확장"
        },
        {
            "시나리오": "API 데이터 수집 및 저장",
            "난이도": "기초",
            "Python_라이브러리": "requests, json, schedule",
            "주요_단계": "API 호출 → JSON 파싱 → 데이터 정규화 → DB 저장",
            "n8n_노드": "Schedule → HTTP Request → Function → Database Insert",
            "적용_부서": "마케팅, 영업팀",
            "도입_효과": "실시간 데이터 수집, 수동 작업 100% 제거",
            "확장_아이디어": "API 장애 감지 및 재시도 로직"
        }
    ],
    
    "웹 크롤링 및 모니터링": [
        {
            "시나리오": "경쟁사 가격 모니터링",
            "난이도": "중급",
            "Python_라이브러리": "beautifulsoup4, selenium, pandas",
            "주요_단계": "웹페이지 접속 → 데이터 추출 → 가격 비교 → 알림",
            "n8n_노드": "Schedule → HTTP Request → HTML Extract → IF → Slack",
            "적용_부서": "마케팅, 상품기획",
            "도입_효과": "가격 변동 실시간 파악, 대응 시간 95% 단축",
            "확장_아이디어": "가격 최적화 AI 모델 연동"
        },
        {
            "시나리오": "구인공고 자동 수집 및 분석",
            "난이도": "중급",
            "Python_라이브러리": "selenium, beautifulsoup4, nltk",
            "주요_단계": "사이트 크롤링 → 공고 파싱 → 키워드 추출 → DB 저장",
            "n8n_노드": "Schedule → HTTP Request → HTML Extract → Set → MySQL",
            "적용_부서": "HR, 경영지원",
            "도입_효과": "채용 트렌드 분석, 경쟁사 채용 동향 파악",
            "확장_아이디어": "지원자 자동 매칭 시스템"
        },
        {
            "시나리오": "뉴스 및 키워드 모니터링",
            "난이도": "기초",
            "Python_라이브러리": "requests, beautifulsoup4, re",
            "주요_단계": "RSS/웹 크롤링 → 키워드 필터링 → 요약 생성 → 알림",
            "n8n_노드": "Schedule → RSS Read → IF → Slack/Email",
            "적용_부서": "PR팀, 경영진",
            "도입_효과": "이슈 대응 시간 80% 단축, 브랜드 모니터링 강화",
            "확장_아이디어": "감정 분석 및 위기 조기 경보"
        },
        {
            "시나리오": "웹사이트 가동 상태 모니터링",
            "난이도": "입문",
            "Python_라이브러리": "requests, time, smtplib",
            "주요_단계": "URL 핑 → 응답 코드 확인 → 로그 기록 → 알림",
            "n8n_노드": "Schedule → HTTP Request → IF → Multiple Notifications",
            "적용_부서": "IT운영팀, 개발팀",
            "도입_효과": "다운타임 80% 감소, 평균 복구 시간 70% 단축",
            "확장_아이디어": "성능 메트릭 수집 및 이상 탐지"
        }
    ],
    
    "알림 및 커뮤니케이션": [
        {
            "시나리오": "Slack 자동 알림 및 보고",
            "난이도": "입문",
            "Python_라이브러리": "slack-sdk, requests",
            "주요_단계": "이벤트 감지 → 메시지 포맷 → Slack 전송",
            "n8n_노드": "Trigger (any) → Set → Slack Send Message",
            "적용_부서": "전 부서",
            "도입_효과": "실시간 알림으로 대응 시간 60% 단축",
            "확장_아이디어": "인터랙티브 버튼으로 승인 프로세스 통합"
        },
        {
            "시나리오": "회의 일정 자동 조율",
            "난이도": "중급",
            "Python_라이브러리": "google-calendar-api, datetime, pytz",
            "주요_단계": "참석자 가용성 조회 → 최적 시간 계산 → 초대 발송",
            "n8n_노드": "Webhook → Google Calendar (free/busy) → Function → Calendar Event",
            "적용_부서": "전 부서",
            "도입_효과": "회의 일정 조율 시간 85% 단축, 회의 충돌 90% 감소",
            "확장_아이디어": "회의실 및 장비 자동 예약"
        },
        {
            "시나리오": "팀 일일 리포트 자동 생성",
            "난이도": "기초",
            "Python_라이브러리": "jira-python, pandas, slack-sdk",
            "주요_단계": "작업 데이터 조회 → 진행 상황 집계 → 리포트 생성 → 전송",
            "n8n_노드": "Schedule → Jira → Aggregate → Slack",
            "적용_부서": "개발팀, 프로젝트팀",
            "도입_효과": "일일 리포트 작성 시간 100% 절약, 투명성 향상",
            "확장_아이디어": "리스크 자동 감지 및 조기 경보"
        }
    ],
    
    "HR 및 온보딩": [
        {
            "시나리오": "신입사원 온보딩 자동화",
            "난이도": "중급",
            "Python_라이브러리": "requests, jinja2, schedule",
            "주요_단계": "입사 정보 수신 → 계정 생성 → 문서 발송 → 일정 등록",
            "n8n_노드": "Webhook → Multiple API calls → Email → Calendar",
            "적용_부서": "HR, IT",
            "도입_효과": "온보딩 시간 60% 단축, 준비 누락 제로화",
            "확장_아이디어": "개인화된 온보딩 경로 자동 생성"
        },
        {
            "시나리오": "휴가 신청 및 승인 자동화",
            "난이도": "기초",
            "Python_라이브러리": "flask, sqlalchemy, smtplib",
            "주요_단계": "신청서 제출 → 승인 라우팅 → 캘린더 업데이트 → 알림",
            "n8n_노드": "Webhook → IF → Email → Google Calendar → Database",
            "적용_부서": "HR, 전 부서",
            "도입_효과": "승인 시간 70% 단축, 휴가 관리 효율 향상",
            "확장_아이디어": "휴가 패턴 분석 및 인력 계획"
        },
        {
            "시나리오": "근태 데이터 수집 및 리포트",
            "난이도": "기초",
            "Python_라이브러리": "pandas, datetime, openpyxl",
            "주요_단계": "출퇴근 데이터 수집 → 근무 시간 계산 → 이상 감지 → 리포트",
            "n8n_노드": "Schedule → API Query → Function → Excel → Email",
            "적용_부서": "HR, 경영지원",
            "도입_효과": "급여 처리 시간 80% 단축, 근태 이상 자동 감지",
            "확장_아이디어": "생산성 패턴 분석 및 인사이트"
        }
    ],
    
    "영업 및 CRM": [
        {
            "시나리오": "리드 자동 스코어링 및 할당",
            "난이도": "중급",
            "Python_라이브러리": "requests, pandas, sklearn",
            "주요_단계": "리드 데이터 수집 → 스코어 계산 → 우선순위 지정 → CRM 업데이트",
            "n8n_노드": "Webhook → Function (scoring) → IF → CRM Update → Slack",
            "적용_부서": "영업팀, 마케팅",
            "도입_효과": "리드 전환율 40% 향상, 영업 효율 증대",
            "확장_아이디어": "예측 모델로 성공 확률 계산"
        },
        {
            "시나리오": "고객 팔로업 자동화",
            "난이도": "기초",
            "Python_라이브러리": "requests, jinja2, schedule",
            "주요_단계": "상호작용 추적 → 팔로업 타이밍 계산 → 이메일 생성 → 발송",
            "n8n_노드": "Schedule → CRM Query → IF → Email Send → CRM Update",
            "적용_부서": "영업팀, 고객성공팀",
            "도입_효과": "팔로업 누락 95% 감소, 고객 만족도 향상",
            "확장_아이디어": "개인화 추천 엔진 통합"
        },
        {
            "시나리오": "계약서 자동 생성 및 전송",
            "난이도": "중급",
            "Python_라이브러리": "docxtpl, PyPDF2, requests",
            "주요_단계": "CRM 데이터 조회 → 템플릿 생성 → PDF 변환 → 전자서명 요청",
            "n8n_노드": "Webhook → CRM → Function → PDF Generator → DocuSign",
            "적용_부서": "영업팀, 법무팀",
            "도입_효과": "계약 체결 시간 75% 단축, 오류율 90% 감소",
            "확장_아이디어": "계약 조건 AI 최적화"
        }
    ],
    
    "재무 및 회계": [
        {
            "시나리오": "청구서 자동 처리 (AP 자동화)",
            "난이도": "중급",
            "Python_라이브러리": "pytesseract, pandas, sqlalchemy",
            "주요_단계": "청구서 수신 → OCR 데이터 추출 → 3-way 매칭 → 승인 라우팅",
            "n8n_노드": "Email → OCR API → Database Query → IF → Approval → ERP",
            "적용_부서": "회계팀, 구매팀",
            "도입_효과": "처리 시간 85% 단축, 비용 30% 절감 (Siemens 사례)",
            "확장_아이디어": "이상 거래 자동 탐지 및 알림"
        },
        {
            "시나리오": "경비 보고서 자동화",
            "난이도": "기초",
            "Python_라이브러리": "PIL, pandas, smtplib",
            "주요_단계": "영수증 업로드 → OCR 처리 → 비용 분류 → 승인 요청",
            "n8n_노드": "Webhook → OCR → Function → Database → Email",
            "적용_부서": "전 부서, 회계팀",
            "도입_효과": "경비 처리 시간 70% 단축, 정확도 향상",
            "확장_아이디어": "예산 초과 자동 경고 및 분석"
        },
        {
            "시나리오": "재무 리포트 자동 생성",
            "난이도": "중급",
            "Python_라이브러리": "pandas, matplotlib, reportlab",
            "주요_단계": "데이터 조회 → 집계 및 분석 → 차트 생성 → PDF 리포트",
            "n8n_노드": "Schedule → Database → Function → Chart → PDF → Email",
            "적용_부서": "재무팀, 경영진",
            "도입_효과": "월간 리포트 작성 시간 90% 단축 (8시간→45분)",
            "확장_아이디어": "예측 분석 및 시나리오 시뮬레이션"
        }
    ]
}

# Count total scenarios
total_scenarios = sum(len(scenarios) for scenarios in automation_scenarios.values())
print(f"총 자동화 시나리오 수: {total_scenarios}개")
print(f"카테고리 수: {len(automation_scenarios)}개\n")

# Create summary by category
for category, scenarios in automation_scenarios.items():
    print(f"{category}: {len(scenarios)}개")
